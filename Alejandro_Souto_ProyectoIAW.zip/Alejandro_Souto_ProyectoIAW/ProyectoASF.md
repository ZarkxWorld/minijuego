# Creando un juego con Phaser

#### Para crear el juego utilizaremos varias herramientas
1. Visual Code Studio
2. Phaser 3
3. Photoshop cs6
4. GitHub

Para comenzar este proyecto, instalaremos en nuestra máquina el programa Visual Code Studio, dentro del mismo tendremos varias extensiones que podremos instalar, las cuales enumeraré a continuación:

- Beautify: sirve para dejar el código algo más bonito.
- Live Server: funciona como un servidor para poder ver cómo va tu proyecto.
- Spanish Language Pack for Visual Studio Code: sirve para poner el idioma en español.
- Markdown All in One: para documentar el proyecto.
- Markdown PDF: para poder exportar el trabajo.

Tras realizar la instalación de todas las extensiones, procederemos a realizar la instalación de phaser; para ello creamos la carpeta en la que haremos nuestro proyecto y la incluiremos dentro del programa arrastrándola, creamos un html simple y abriremos la terminal del Visual Code Studio en la cuál pondremos 

~~~
npm init -y
~~~
para poder activar el npm, posteriormente se nos creará el archivo package.json

Una vez realizado esto, procederemos a instalar el phaser3 del mismo modo que el npm (en la terminal de Visual Code Studio) con el comando:

~~~
npm install --save phaser
~~~

Con esto se nos crearán varias carpetas para poder empezar a trabajar.

También procederemos a instalar Photoshop cs6 u otro programa de edición y/o creación de imágenes para poder realizar los diseños de nuestros juegos.

Otro punto a tener en cuenta es qué queremos crear, porque de nada vale empezar sin tener un objetivo medianamente claro, en mi caso quise hacer guiño al primer juego de la historia, es decir, el pong y también al primer juego que yo mismo he jugado: el snake.

Teniendo esto claro, lo que haremos será definir qué queremos tener para ambos juegos.

Una vez creadas las imágenes, se incluirán en una de las carpetas creadas llamada "assets".

Mostraré a continuación las que he escogido y/o creado para el pong:
- La pelota: 
![Pelota](assets/ball.png)
- Las palas: ![Pala1](assets/left_pallete.png)![Pala2](assets/right_pallete.png)
- El campo: ![Campo](assets/tenis.jpg)

Con eso tenemos el material para el pong; también pondré los del snake

- El cuerpo: ![Cuerpo](snake-final/snake/assets/body.png)
- La comida: ![Comida](snake-final/snake/assets/food.png)
- El Tablero: ![Tablero](snake-final/snake/assets/tablero.png)
- La fuente: ![Fuente](snake-final/snake/assets/font/font.png)


Teniendo ya los materiales, podremos comenzar nuestro trabajo en el código.

# Pong


Comenzaremos por el pong; el html lo haremos de la siguiente forma:

~~~
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pong</title>
    <style>
        main {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
        }
        #contenedor {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <main>
        <div id="contenedor"></div>
    </main>

    <script src="./node_modules/phaser/dist/phaser.js"></script>
    <script src="./src/init.js" type="module"></script>
</body>
</html>
~~~

¿Qué vemos aquí?
Bien, principalmente el código general del html es sencillo dado que tiene la declaración doctype, las etiquetas habituales pero sí agregamos un estilo con diferentes características, un contenedor con margen y dentro del body agregamos un div para el contenedor y también dos scripts en el que se recogerán el phaser.js (se crea automáticamente al instalar el phaser) y otro para el init.js que es una parte del trabajo que realizaremos.

Por todo lo demás, no necesitaremos tocar el html.

Ahora tenemos que trabajar en el contenido del src: el bootloader.js y el init.js (después también tendremos que trabajar dentro de la carpeta gameObjets con palas.js y en la carpeta scenes con scene_play.js)

Bien, para comenzar, trabajaremos con el bootloader en el cuál dejaremos el código de la siguiente manera:

~~~
class Bootloader extends Phaser.Scene {
    constructor() {
        super({key: "Bootloader"});
    }
    preload() {
        this.load.on("complete", () => {
            this.scene.start("Scene_play");
        });
        this.load.image("cancha", "./assets/tenis.png");
        this.load.image("ball", "./assets/ball.png");
        this.load.image("izquierda", "./assets/left_pallete.png");
        this.load.image("derecha", "./assets/right_pallete.png");
        this.load.image("separador", "./assets/separator.png");
        this.load.audio("rebote", ["./assets/musica/Rebote.mp3","./assets/musica/Rebote.wav"]);
    }
}
export default Bootloader;
~~~

¿Qué vemos aquí?
En este js tendremos la clase que se llamará Bootloader, y que se exiende a Phaser.Scene
También vemos el preload que son todas las cosas que cargará antes de que comience el juego, como se ve, son las imágenes; finalmente este resultado se exporta como Bootloader.

Ahora podremos trabajar con el init.js en el cuál pondremos el siguiente código

~~~
import Bootloader from './bootloader.js';
import Scene_play from './scenes/scene_play.js';
const config = {
    width: 840,
    height: 600,
    parent: "contenedor",
    physics: {
        default: "arcade"
    },
    scene: [
        Bootloader,
        Scene_play
    ]
}

new Phaser.Game(config);
~~~

¿Qué vemos aquí?

Bien, aquí podemos ver que se importan las clases (Bootloader y Scene_Play) y la ruta dónde están.
Agregamos también una configuración de constante que nos da el tamaño del campo con las medidas que he puesto y el parent que viene a ser el div utilizado en el html; la escena se carga también aquí.

Para poder hacer que funcione el juego debemos agregar las diferentes dinámicas, tanto en las palas como en el scene_play.

Considero que tener la dinámica de las palas es bastante importante. Es un código relativamente sencillo:

~~~
class Palas extends Phaser.GameObjects.Sprite {
    constructor(scene, x, y, type) {
        super(scene, x, y, type);
        scene.add.existing(this);
        scene.physics.world.enable(this);
        this.body.immovable = true;
        this.body.setCollideWorldBounds(true);
    }
}
export default Palas;
~~~

Se crea la clase palas extendido a un objeto con sprite, al construir, en escena se le da la opción de tener coordenadas, se le agrega una escena existente que viene a ser this (poco original pero sencillo), también la física del "mundo", hacemos que cuando choquen contra ellas, pues rebote.

Finalmente llega el meollo de la cuestión, es decir, el código más grande: Las escenas

~~~
import Palas from '../gameObjects/palas.js';
class Scene_play extends Phaser.Scene {
    constructor() {
        super({key: "Scene_play"});
    }

    create() {
        let center_width = this.sys.game.config.width/2;
        let center_height = this.sys.game.config.height/2;

        // Separador
        this.add.image(center_width, center_height, "separador");
        this.add.image(center_width, center_height, "cancha");
    
        // Palas
        this.izquierda = new Palas(this, 30, center_height, "izquierda");
        this.derecha = new Palas(this, this.sys.game.config.width-30, center_height, "derecha");
        
        // bola
        this.physics.world.setBoundsCollision(false, false, true, true);
        this.ball = this.physics.add.image(center_width, center_height, "ball");
        this.ball.setCollideWorldBounds(true);
        this.ball.setBounce(1);
        this.ball.setVelocityX(-180);

        // Fisicas
        this.physics.add.collider(this.ball, this.izquierda, this.chocaPala, null, this);
        this.physics.add.collider(this.ball, this.derecha, this.chocaPala, null, this);

        // Controles
        // Pala derecha
        this.cursor = this.input.keyboard.createCursorKeys();

        // Pala izquierda
        this.cursor_W = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        this.cursor_S = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);

        // Sonido
        let audio = this.sound.add("rebote");

    }
    update() {
        if(this.ball.x < 0 || this.ball.x > this.sys.game.config.width) {
            this.ball.setPosition(this.sys.game.config.width/2, this.sys.game.config.height/2);
        }

        // Control de las palas
        // pala derecha
        if(this.cursor.down.isDown) {
            this.derecha.body.setVelocityY(300);
        } else if(this.cursor.up.isDown) {
            this.derecha.body.setVelocityY(-300);
        } else {
            this.derecha.body.setVelocityY(0);
        }
        // Pala izquierda
        if(this.cursor_S.isDown) {
            this.izquierda.body.setVelocityY(300);
        } else if(this.cursor_W.isDown) {
            this.izquierda.body.setVelocityY(-300);
        } else {
            this.izquierda.body.setVelocityY(0);
        }


    }

    chocaPala() {
        this.ball.setVelocityY(Phaser.Math.Between(-320, 320));
    }
}
export default Scene_play;
~~~

Aquí importamos el objeto palas para poder ponerlas en su sitio, se crea la escena clase también con su clave.

Realizamos la creación de los tamaños para que se pueda centrar y a partir de ahí colocar todos los objetos. Tenemos el separador que marcará justo el centro del campo (posteriormente he agregado el campo de tenis por cuestión estética).
Las palas las agregamos con sus propias coordenadas dentro del juego, es decir, cada una en un lateral.

Para trabajar con la pelota, se le añade una física para que pueda rebotar con las colisiones, ahí le agregamos la condición verdadera o falsa para que rebote en los lados superior e inferior y no rebote en los laterales. Obviamente también pondremos la imagen agregando que salga desde el centro. Para acabar le agregaremos una velocidad para las coordenadas X.

En las físicas agregaremos las colisiones para con las palas.


Ahora algo importante: Los controles

~~~
// Controles
        // Pala derecha
        this.cursor = this.input.keyboard.createCursorKeys();

        // Pala izquierda
        this.cursor_W = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        this.cursor_S = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
~~~
Como se puede apreciar, la pala derecha se mueve con la cruceta mientras que la pala izquierda se ha agregado el control con la W y la S

Y nos queda para poder acabar, el tema de las actualizaciones

~~~
update() {
        if(this.ball.x < 0 || this.ball.x > this.sys.game.config.width) {
            this.ball.setPosition(this.sys.game.config.width/2, this.sys.game.config.height/2);
        }

        // Control de las palas
        // pala derecha
        if(this.cursor.down.isDown) {
            this.derecha.body.setVelocityY(300);
        } else if(this.cursor.up.isDown) {
            this.derecha.body.setVelocityY(-300);
        } else {
            this.derecha.body.setVelocityY(0);
        }
        // Pala izquierda
        if(this.cursor_S.isDown) {
            this.izquierda.body.setVelocityY(300);
        } else if(this.cursor_W.isDown) {
            this.izquierda.body.setVelocityY(-300);
        } else {
            this.izquierda.body.setVelocityY(0);
        }


    }

    chocaPala() {
        this.ball.setVelocityY(Phaser.Math.Between(-320, 320));
    }
}
export default Scene_play;
~~~

Aquí trabajaremos con condiciones, empezando con la pelota en la que se pone la posición.
Se continúa con el codigo de las palas en la que ponemos que si va hacia abajo en el eje Y usará una velocidad de 300 y lo mismo para subir, el mismo código se utiliza para la pala izquierda cambiando las flechas por la W y la S.

Para finalizar pondremos una velocidad a la pelota una vez choque con la pala, ésta se dará mediante una fórmula matemática y la velocidad estará entre las dos que querramos.

Nada más exportamos el código y tendremos nuestro pong acabado.

![Pong](/home/tarde/Escritorio/proyecto_iaw/pong.png)


# Snake


La estructura que usaré de carpetas será la siguiente:

![EstructuraSnake](/home/tarde/Escritorio/proyecto_iaw/estructuraSnake.png)

Las imágenes empleadas serán:

- El cuerpo: ![Cuerpo](snake-final/snake/assets/body.png)
- La comida: ![Comida](snake-final/snake/assets/food.png)
- El Tablero: ![Tablero](snake-final/snake/assets/tablero.png)
- La fuente: ![Fuente](snake-final/snake/assets/font/font.png)

Para trabajar con el Snake necesitaremos crear un html para él, se verá de la siguiente manera:

~~~
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Snake</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }
        body {
            display: flex;
            justify-content: center;
            background-color: #2c3e50;
        }
        #container {
            margin-top: 130px;
            transform: scale(2);
        }
    </style>
</head>
<body>
    <div id="container"></div>

    <script src="phaser.min.js"></script>
    <script src="./src/main.js" type="module"></script>
</body>
</html>
~~~

Tendrá lo mismo que el pong sin apenas cambios; quizá el cambio más radical sea en el script que en lugar de utilizar el phaser.js utilizo el phaser.min.js que es una versión un tanto más ligera que la otra.

Para empezar podremos crear nuestro main.js de la siguiente manera:

~~~
import Bootloader from './bootloader.js';
import Play from './scenes/play.js';
import Gameover from './scenes/gameover.js';
import UI from './scenes/UI.js';
import Menu from './scenes/menu.js';

const config = {
    title: 'Snake',
    width: 320,
    height: 180,
    type: Phaser.AUTO,
    parent: 'container',
    backgroundColor: '#000000',
    pixelArt: true,
    physics: {
        default: "arcade",
        // arcade: {
        //     gravity: { y: 100 }
        // }
    },
    scene: [Bootloader, Play, Gameover, UI, Menu]
};

new Phaser.Game(config);
~~~

Las importaciones se van agregando conforme se hana los archivos js. 
Aquí lo importante en un principio va a ser importar el Bootloader que crearemos a continuación, la constante en la que le agregaremos la configuración de la pantalla y el nuevo juego phaser.

Con el Bootloader haremos lo siguiente:

~~~
class Bootloader extends Phaser.Scene {
    constructor() {
        super('Bootloader');
    }

    preload() {
        console.log('Soy Bootloader');
        this.load.image('cuerpo', './assets/body.png');
        this.load.image('comida', './assets/food.png');
        this.load.image('tablero', './assets/tablero.png');

        this.load.json('fontJSON', './assets/font/font.json');
        this.load.image('font', './assets/font/font.png');

        this.load.on('complete', () => {
            const fontJSON = this.cache.json.get('fontJSON');
            this.cache.bitmapFont.add('pixel', Phaser.GameObjects.RetroFont.Parse(this, fontJSON));

            this.scene.start('Menu');
        });
        
    }

}

export default Bootloader;
~~~

Se agrega la clase y se hace la precarga de las imagenes y la fuente (tipografía de letra), en la cual se hace un load.on para poder cargarla mediante un JSON.

Le decimos también que la escena comenzará con el Menú, que será lo siguiente en crearse.

~~~
class Menu extends Phaser.Scene {
    constructor() {
        super('Menu');
    }

    preload() {
        console.log('Soy Menu');
    }

    create() {
        this.add.image(this.sys.game.config.width/2, this.sys.game.config.height/2 - 50, 'comida').setScale(6);
        this.add.dynamicBitmapText(this.sys.game.config.width/2, this.sys.game.config.height/2
            , 'pixel', 'SNAKE', 18).setOrigin(0.5);

        const pressButton = this.add.dynamicBitmapText(this.sys.game.config.width/2, this.sys.game.config.height - 40
            , 'pixel', 'PRESS ANY BUTTON', 8).setOrigin(0.5);
    
        this.tweens.add({
            targets: pressButton,
            alpha: 0,
            ease: (x) => x < 0.5 ? 0 : 1,
            duration: 500,
            yoyo: true,
            repeat: -1
        });
        this.input.keyboard.on('keydown_RIGHT', () => {
            this.scene.start('Play');
        });
        this.input.keyboard.on('keydown_LEFT', () => {
            this.scene.start('Play');
        });
        this.input.keyboard.on('keydown_UP', () => {
            this.scene.start('Play');
        });
        this.input.keyboard.on('keydown_DOWN', () => {
            this.scene.start('Play');
        });

        this.input.keyboard.on('keydown_ENTER', () => {
            this.scene.start('Play');
        });
        this.input.on('pointerdown', () => {
            this.scene.start('Play');
        })

    }

}

export default Menu;
~~~

Aquí agregamos una pantalla de inicio en la que tanto con click de ratón como con alguna tecla de control de teclado se comenzará el juego. Aquí también añadimos la imagen de la comida como parte de la pantalla inicio y obviamente el nombre del juego en conjunto con que se presione la tecla (éste será intermitente).

![Menú](/home/tarde/Escritorio/proyecto_iaw/snake.png)

Crearemos también una pantalla para el fin de juego (GameOver)

![Menú](/home/tarde/Escritorio/proyecto_iaw/gameover.png)

Para lograr ésto, el código que emplearemos será el siguiente:

~~~
class Gameover extends Phaser.Scene {
    constructor() {
        super('Gameover');
    }

    preload() {
        console.log('Soy Gameover');
    }

    create() {
        this.scene.stop('UI');
        this.add.dynamicBitmapText(this.sys.game.config.width/2, 
            this.sys.game.config.height/2 - 30, 
            'pixel', 'GAMEOVER', 20).setOrigin(0.5);
        
        this.evento = setTimeout(() => {
            this.salirEscene();
        }, 5000);
        
        this.input.keyboard.on('keydown_ENTER', () => {
            this.salirEscene();
        });
        this.input.on('pointerdown', () => {
            this.salirEscene();
        })
    }

    salirEscene() {
        clearTimeout(this.evento);
        this.scene.start('Menu');
    }

}

export default Gameover;
~~~

Se crea la clase del gameover.
Dentro del create se para la escena UI (que veremos al final) y se agregará el texto con la fuente que teníamos. El evento dura una cantidad de tiempo reducida o hasta que presiones enter o un click de ratón, esta se exporta como Gameover para agregar posteriormente al bootloader.js


Ahora haremos la parte de juego:

~~~
import Snake from '../gameobjects/Snake.js';
import Comida from '../gameobjects/Comida.js';

class Play extends Phaser.Scene {
    constructor() {
        super('Play');
    }

    preload() {
        console.log('Escena play');
        this.snake = new Snake(this);
        this.comida = new Comida(this);
    }
    create() {
        
        this.scene.launch('UI');
        const sceneUI = this.scene.get('UI');

        this.input.keyboard.on('keydown_RIGHT', () => {
            this.snake.changeMov('derecha');
        });
        this.input.keyboard.on('keydown_LEFT', () => {
            this.snake.changeMov('izquierda');
        });
        this.input.keyboard.on('keydown_UP', () => {
            this.snake.changeMov('arriba');
        });
        this.input.keyboard.on('keydown_DOWN', () => {
            this.snake.changeMov('abajo');
        });

        // Colision de cabeza con comida
        this.physics.add.collider(this.snake.cuerpo[0], this.comida.comida, () => {
            this.comida.crearComida();
            this.snake.crece();
            sceneUI.addPoint();
        });
    }
    update(time) {
        this.snake.update(time);
    }
}

export default Play;
~~~

Esta parte de juego tendrá el movimiento de nuestra serpiente con las flechas, también tiene la escena para la UI en la que se agregarán los puntos, no obstante lo veremos a continuación.
Aquí es dónde importaremos la comida y el cuerpo de la serpiente y se precarga. Agregamos la física de colisión, es decir, cuando la cabeza choca con la comida, la serpiente crece un cuadro además de agregar puntos.

Ahora trabajamos con los puntos:

~~~
class UI extends Phaser.Scene {
    constructor() {
        super('UI');
    }

    preload() {
        console.log('Soy UI');
    }
    
    create() {
        this.add.image(0, 0, 'tablero').setOrigin(0);
        this.add.dynamicBitmapText(10, 7, 'pixel', 'PUNTOS', 8);
        this.puntos = this.add.dynamicBitmapText(this.sys.game.config.width - 60, 7, 'pixel', Phaser.Utils.String.Pad(0, 6, 0, 1), 8);
    }
    addPoint() {
        this.puntos.setText(
            Phaser.Utils.String.Pad(parseInt(this.puntos.text) + 10, 6, 0, 1)
        );
    }

}

export default UI;
~~~

Aquí estambleceremos una imagen dentro del tablero que creamos en la que añadimos un texto con los puntos, para poder agregar los puntos se hace un cálculo matemático y se establece que sea un número en lugar de texto.

Obviamente la serpiente no crecerá sola, aquí entran los gameobjects.

Primero haremos la comida

~~~
class Comida {
    constructor(scene) {
        this.scene = scene;
        
        this.comida = this.scene.physics.add.group({
            key: 'comida',
            setXY: {
                x: 30,
                y: 30
            }
        });
        
        this.comida.getChildren()[0].setOrigin(0).setDepth(-1);
    }

    crearComida() {
        let x = Phaser.Math.Between(30, this.scene.sys.game.config.width - 30);
        let y = Phaser.Math.Between(30, this.scene.sys.game.config.height - 30);
        
        x = Phaser.Math.Snap.To(x, 10);
        y = Phaser.Math.Snap.To(y, 10);
        
        this.comida.getChildren()[0].destroy();
        this.comida.create(x, y, 'comida');
        this.comida.getChildren()[0].setOrigin(0).setDepth(-1);
    }
}

export default Comida;
~~~

Esta frutita naranja se creará de forma random entre unas coordenadas situadas entre 30 y -30

Finalmente la serpiente que es lo que puede llevar algo más de trabajo

~~~
class Snake {
    constructor(scene) {
        this.scene = scene;
        this.cuerpo = [];
        this.dir = 'izquierda';
        this.timmer = 0;
        this.oldDir = 'derecha';

        // genera cuerpo
        for (let i = 0; i < 3; i++) {
            this.cuerpo.push(
                this.scene.physics.add.image(100 + i * 10, 100, 'cuerpo')
                .setOrigin(0)
            );
        }

        // genera colisiones
        for (let i = 1; i < 10; i++) {
                this.scene.physics.add.collider(this.cuerpo[0], this.cuerpo[i], () => this.choca());
        }
    }
    crece() {
        const obj = this.cuerpo[this.cuerpo.length-1];
        const newObj = this.scene.physics.add.image(obj.x, obj.y, 'cuerpo').setOrigin(0);
        this.cuerpo.push(newObj);
        this.scene.physics.add.collider(this.cuerpo[0], newObj, () => this.choca());
    }
    choca() {
        this.scene.scene.start('Gameover');
    }
    changeMov(dir) {
        if (this.oldDir != dir) {
            this.dir = dir;
        }
    }
    update(time) {
        if (time > this.timmer) {

            for (let i = this.cuerpo.length - 1; i > 0; i--) {
                this.cuerpo[i].x = this.cuerpo[i - 1].x;
                this.cuerpo[i].y = this.cuerpo[i - 1].y;

                this.cuerpo[this.cuerpo.length - 1 - i].x = Phaser.Math.Wrap(this.cuerpo[this.cuerpo.length - 1 - i].x,
                    0,
                    this.scene.sys.game.config.width);

                this.cuerpo[this.cuerpo.length - 1 - i].y = Phaser.Math.Wrap(this.cuerpo[this.cuerpo.length - 1 - i].y,
                    20,
                    this.scene.sys.game.config.height);

            }

            switch (this.dir) {
                case 'derecha':
                    this.cuerpo[0].x += 10;
                    this.oldDir = 'izquierda';
                    break;
                case 'izquierda':
                    this.cuerpo[0].x -= 10;
                    this.oldDir = 'derecha';
                    break;
                case 'arriba':
                    this.cuerpo[0].y -= 10;
                    this.oldDir = 'abajo';
                    break;
                case 'abajo':
                    this.cuerpo[0].y += 10;
                    this.oldDir = 'arriba';
                    break;
            }
            this.timmer = time + 150;
        }
    }
}
export default Snake;
~~~

Aquí tendrá el movimiento además de la generación de cuerpo cada vez que choca contra una fruta, no obstante si choca contra ella misma saltará la escena del Gameover que vimos anteriormente.

Aquí acaba el snake.

Como he decidido subirlo a GitHub, he agregado una página que funcionará como índex en la que he puesto ambos juegos.

~~~
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
    h1 {
        text-align: center;
        text-decoration: aquamarine;
        font-size: 50px;
        text-decoration-line: underline;
        color:lavender;
    }
    html {
        background: url(fondo.jpg) no-repeat center center fixed;
        background-size: cover;
        -moz-background-size: cover;
        -webkit-background-size: cover;
        -o-background-size: cover;
}
.neon { 
font-size: 50px; 
letter-spacing:-2px; 
color: #fff; 
text-shadow: 0 0 5px #fff, 0 0 10px #fff, 0 0 15px #fff, 0 0 20px #ff00de, 0 0 25px #ff00de; 
-webkit-text-fill-color: #F4ECFF; 
-webkit-text-stroke-color:#C546F7; 
-webkit-text-stroke-width:0.2px; 
-moz-text-fill-color: #F4ECFF; 
-moz-text-stroke-color:#C546F7; 
-moz-text-stroke-width:0.2px; 
} 
    </style>
    <title>Juegos</title>
</head>
<body>
    <h1 class="neon">Elige el juego que deseas probar</h1>
    <a title="Snake" href="https://zarkxworld.github.io/snake/"><img src="snake.png" /></a>
    <a title="Pong" href="pong.html"><img src="pong.jpg" /></a>
</body>
</html>
~~~

El código es sencillo, un simple html al que le he agregado algo de estilo, un h1 para título y dos enlaces a los juegos (funciona al clickear la imagen).

Este index está en la misma zona que el pong por eso el pong es un enlace a la misma carpeta, no obstante el Snake va directamente a otra página dado que lo he subido de forma independiente.


Para acabar subiremos nuestro proyecto a GitHub y lo pondremos en funcionamiento.

[Prueba los juegos](https://zarkxworld.github.io/minijuego/)

![final](/home/tarde/Escritorio/proyecto_iaw/final.png)

